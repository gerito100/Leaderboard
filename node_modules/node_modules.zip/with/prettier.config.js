module.exports = require('@forbeslindesay/tsconfig/prettier');
